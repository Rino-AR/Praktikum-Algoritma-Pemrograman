import math

def luas_lingkaran():
    r = float(input("Masukkan jari-jari lingkaran: "))
    return math.pi * r**2

def luas_persegi():
    s = float(input("Masukkan sisi persegi: "))
    return s**2

def luas_persegi_panjang():
    p = float(input("Masukkan panjang persegi panjang: "))
    l = float(input("Masukkan lebar persegi panjang: "))
    return p * l